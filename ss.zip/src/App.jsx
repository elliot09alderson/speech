import React from "react";
import { useEffect } from "react";

import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";

const App = () => {
  const {
    transscript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition();

  if (!browserSupportsSpeechRecognition) {
    alert("not supported");
  }
  useEffect(() => {
    SpeechRecognition.startListening();
  }, []);
  return (
    <div>
      <p>Microphone: {listening ? "on" : "off"}</p>
      <button onClick={SpeechRecognition.startListening}>on</button>
      <button onClick={SpeechRecognition.stopListening}>off</button>
      <button onClick={resetTranscript}>reset</button>

      <h2>{transscript}</h2>
    </div>
  );
};

export default App;
